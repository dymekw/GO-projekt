package app;

import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

import chan.Chan;
import divideandconquer.DivideAndConquer;
import geometry.Vertex;
import graham.Graham;
import jarvis.Jarvis;
import quickhull.QuickHull;
import util.DataProvider;

public class Test {
	public static void main(String[] args) {
		DataProvider provider = new DataProvider();
		Collection<Vertex> data = provider.getPointsFromFile("/home/wojciech_dymek/GO/lab 02/a.txt");

		System.out.println("Number of points: " + data.size());
		Map<String, CHService> services = new HashMap<>();
		services.put("Graham", new Graham());
		services.put("Jarvis", new Jarvis());
		services.put("QuickHull", new QuickHull());
		services.put("DivideAndConquer", new DivideAndConquer(1000));
		services.put("Chan", new Chan(28, 1));
		
		services.forEach((serviceName, service) -> {
			LinkedList<Vertex> result = compute(service, data);
			
			System.out.println("###############");
			System.out.println(serviceName);
			System.out.println("CH size: " + result.size());
			
			for (Vertex point3d : result) {
				System.out.println("\t" + point3d.getPoint().getX() + " " + point3d.getPoint().getY());
			}
			
			service.getTimes().forEach((name, time) -> {
				System.out.println(name + time);
			});
		});
	}
	
	private static LinkedList<Vertex> compute(CHService service, Collection<Vertex> data) {
		LinkedList<Vertex> result = service.computeCH(new LinkedList<>(data));
		
		return result;
	}
}
