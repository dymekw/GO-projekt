package app;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import geometry.Vertex;

public interface CHService {
	public LinkedList<Vertex> computeCH(List<Vertex> points);
	public Map<String, Long> getTimes();
}
