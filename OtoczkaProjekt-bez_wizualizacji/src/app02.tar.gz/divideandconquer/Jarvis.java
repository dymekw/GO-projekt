package divideandconquer;

import java.util.LinkedList;
import java.util.List;

import geometry.Vertex;
import util.PointComparator;
import util.Utils;

public class Jarvis {
	public LinkedList<Vertex> computeCH(List<Vertex> points) {
		Vertex initial = Utils.getInitialPoint(points, false);
		LinkedList<Vertex> list = new LinkedList<>();

		Vertex current = initial;

		do {
			PointComparator comparator = new PointComparator(current);
			points.sort(comparator);

			current = points.get(0);

			list.add(current);
		} while (current != initial);
		
		return list;
	}
}
