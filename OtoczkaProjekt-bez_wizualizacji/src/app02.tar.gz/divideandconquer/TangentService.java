package divideandconquer;

import java.util.List;

import geometry.Point3D;
import geometry.Vertex;
import util.DeterminantCalc;

public class TangentService {
	private static DeterminantCalc calc = new DeterminantCalc();
	
	public boolean isTangent(Point3D a, Point3D b, List<Vertex> set, boolean upper) {
		int sign = 0; 
		
		for (Vertex point3d : set) {
			int currSign = calc.getDeterminantSign(a, b, point3d.getPoint());
			
			if (sign == 0 && currSign != 0) {
				sign = currSign;
			}
			
			if (sign != currSign && currSign != 0) {
				return false;
			}
		}
		
		if (upper) {
			return sign < 0;
		}
		
		return sign > 0;
	}
	
	public boolean isTangent(Point3D a, Point3D b, List<Vertex> A, List<Vertex> B, boolean upper) {
		return isTangent(a, b, A, upper) && isTangent(a, b, B, upper);
	}
}
