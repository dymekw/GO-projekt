package chan;

import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;
import java.util.stream.Collectors;

import app.CHService;
import geometry.Point3D;
import geometry.Vertex;
import util.DeterminantCalc;
import util.Utils;

public class Chan implements CHService {

	private int m;
	private int genVersion;
	private final Graham graham = new Graham();
	private final Random r = new Random();
	private final DeterminantCalc calc = new DeterminantCalc();

	private long totalTime = 0;
	private long subCHsComputationTime = 0;
	private long sortingTime = 0;

	public Chan(int m, int genVersion) {
		this.m = m;
		this.genVersion = genVersion;
	}

	@Override
	public LinkedList<Vertex> computeCH(List<Vertex> points) {
		long startTotal = System.nanoTime();
		List<Vertex> copy = new LinkedList<>(points);

		List<LinkedList<Vertex>> subSets = null;

		switch (genVersion) {
		case 1:
			subSets = generateSubSets(copy);
			break;
		default:
			subSets = generateSubSets2(copy);
		}

		long subCHsGenTime = System.nanoTime();
		List<LinkedList<Vertex>> subCHs = subSets.stream().map(graham::computeCH).collect(Collectors.toList());
		subCHsComputationTime = System.nanoTime() - subCHsGenTime;

		copy = new LinkedList<>(points);
		Vertex current = Utils.getInitialPoint(copy, true);
		LinkedList<Vertex> result = new LinkedList<>();
		result.add(current);

		for (int i = 0; i < m; i++) {
			long sortStart = System.nanoTime();
			LinkedList<Vertex> candidates = new LinkedList<>();
			for (LinkedList<Vertex> list : subCHs) {
				Vertex candidate = getCHCandidate(list, current, 0, list.size() - 1);
				if (Objects.nonNull(candidate)) {
					candidates.add(candidate);
				}
			}
			util.PointComparator deterPointComparator = new util.PointComparator(current);
			candidates.sort(deterPointComparator);
			sortingTime += System.nanoTime() - sortStart;

			current = candidates.getFirst();

			if (current.equals(result.getFirst())) {
				break;
			} else {
				result.add(current);
			}

			if (i + 1 == m) {
				throw new RuntimeException("m is too small");
			}
		}

		totalTime = System.nanoTime() - startTotal;
		return result;
	}

	private Vertex getCHCandidate(LinkedList<Vertex> CH, Vertex P, int first, int last) {
		if (CH.contains(P)) {
			return CH.get((CH.indexOf(P) + 1) % CH.size());
		}

		// only 2 points - check each
		if (last - first <= 1) {
			for (int i = first; i <= last; i++) {
				Vertex prev = CH.get(i > 0 ? i - 1 : CH.size() - 1);
				Vertex next = CH.get((i + 1) % CH.size());
				if (calc.getDeterminantSign(P.getPoint(), CH.get(i).getPoint(), prev.getPoint()) >= 0
						&& calc.getDeterminantSign(P.getPoint(), CH.get(i).getPoint(), next.getPoint()) >= 0) {
					return CH.get(i);
				}
			}
			return null;
		}

		Vertex firstPrev = CH.get(first > 0 ? first - 1 : CH.size() - 1);
		Vertex firstNext = CH.get((first + 1) % CH.size());
		int firstPrevDeterSign = calc.getDeterminantSign(P.getPoint(), CH.get(first).getPoint(), firstPrev.getPoint());
		int firstNextDeterSign = calc.getDeterminantSign(P.getPoint(), CH.get(first).getPoint(), firstNext.getPoint());

		// check first
		if (firstPrevDeterSign >= 0 && firstNextDeterSign >= 0) {
			return CH.get(first);
		}

		int middleIndex = (first + last) / 2;
		Vertex middlePrev = CH.get(middleIndex - 1);
		Vertex middleNext = CH.get(middleIndex + 1);
		double middlePrevDeterSign = calc.getDeterminantSign(P.getPoint(), CH.get(middleIndex).getPoint(), middlePrev.getPoint());
		double middleNextDeterSign = calc.getDeterminantSign(P.getPoint(), CH.get(middleIndex).getPoint(), middleNext.getPoint());

		// check middle
		if (middlePrevDeterSign >= 0 && middleNextDeterSign >= 0) {
			return CH.get(middleIndex);
		}

		// choose chain
		if (firstPrevDeterSign <= 0 && firstNextDeterSign <= 0) { // first is an
																	// opposite
																	// tangent
			if (middleNextDeterSign >= 0) {
				return getCHCandidate(CH, P, first + 1, middleIndex - 1);
			}
			return getCHCandidate(CH, P, middleIndex + 1, last);
		} else if (firstNextDeterSign <= 0) {
			if (middlePrevDeterSign <= 0) {
				return getCHCandidate(CH, P, first + 1, middleIndex - 1);
			}
			return getCHCandidate(CH, P, middleIndex + 1, last);
		} else {
			if (middleNextDeterSign <= 0) {
				return getCHCandidate(CH, P, middleIndex + 1, last);
			}
			return getCHCandidate(CH, P, first + 1, middleIndex - 1);
		}
	}

	private List<LinkedList<Vertex>> generateSubSets(List<Vertex> copy) {
		List<LinkedList<Vertex>> result = new LinkedList<>();

		while (!copy.isEmpty()) {
			int quantity = Math.min(m, copy.size());

			LinkedList<Vertex> subSet = new LinkedList<>();

			for (int i = 0; i < quantity; i++) {
				Vertex p = copy.get(r.nextInt(copy.size()));
				subSet.add(p);
				copy.remove(p);
			}

			result.add(subSet);
		}

		return result;
	}

	private List<LinkedList<Vertex>> generateSubSets2(List<Vertex> copy) {
		List<LinkedList<Vertex>> result = new LinkedList<>();
		Comparator<Vertex> xComp = new Comparator<Vertex>() {
			@Override
			public int compare(Vertex o1, Vertex o2) {
				return (int) Math.signum(o1.getPoint().getX() - o2.getPoint().getX());
			}
		};

		while (!copy.isEmpty()) {
			int quantity = Math.min(m, copy.size());

			LinkedList<Vertex> subSet = new LinkedList<>();

			copy.sort(xComp);
			PointComparator comparator = new PointComparator(copy.get(0));
			copy.sort(comparator);
			for (int i = 0; i < quantity; i++) {
				Vertex p = copy.get(i);
				subSet.add(p);
			}

			copy.removeAll(subSet);
			result.add(subSet);
		}

		return result;
	}

	private static class PointComparator implements Comparator<Vertex> {

		private Point3D p;

		public PointComparator(Vertex p) {
			this.p = p.getPoint();
		}

		@Override
		public int compare(Vertex o1, Vertex o2) {
			return (int) Math.signum(Utils.getDistance(o1.getPoint(), p) - Utils.getDistance(o2.getPoint(), p));
		}

	}

	@Override
	public Map<String, Long> getTimes() {
		Map<String, Long> result = new HashMap<>();

		result.put("Total time: ", totalTime);
		result.put("SubCHs computing time: ", subCHsComputationTime);
		result.put("Sort time: ", sortingTime);

		return result;
	}
}
